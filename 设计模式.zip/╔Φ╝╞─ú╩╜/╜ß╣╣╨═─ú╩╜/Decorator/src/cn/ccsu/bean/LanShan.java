package cn.ccsu.bean;

public class LanShan extends Coffee {

	public static final double prize = 8;

	public LanShan() {
		this.setPrize(prize);
	}
}
