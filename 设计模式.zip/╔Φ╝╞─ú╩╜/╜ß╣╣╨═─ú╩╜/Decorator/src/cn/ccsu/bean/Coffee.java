package cn.ccsu.bean;

public abstract class Coffee extends AbstractDrink {

}
