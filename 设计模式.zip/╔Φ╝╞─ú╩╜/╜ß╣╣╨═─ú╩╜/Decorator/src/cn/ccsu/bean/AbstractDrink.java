package cn.ccsu.bean;

public class AbstractDrink {

	private Double prize;

	public Double getPrize() {
		return prize;
	}

	public void setPrize(Double prize) {
		this.prize = prize;
	}
}
