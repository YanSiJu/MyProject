package cn.csu.bean;

public abstract class AbstractGraph {

	public abstract void draw();

}
