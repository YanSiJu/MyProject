package cn.csu.bean;

public class Square extends AbstractGraph {

	@Override
	public void draw() {
		System.out.println("Draw Square");
	}

}
