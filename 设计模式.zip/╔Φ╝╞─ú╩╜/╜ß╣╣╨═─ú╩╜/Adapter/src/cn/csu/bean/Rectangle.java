package cn.csu.bean;

public class Rectangle extends AbstractGraph {

	@Override
	public void draw() {
		System.out.println("Draw Rectangle");
	}

}
