package cn.csu.bean;

public class Angle {

	public void drawAngle() {
		System.out.println("Draw Angle");
	}

}
