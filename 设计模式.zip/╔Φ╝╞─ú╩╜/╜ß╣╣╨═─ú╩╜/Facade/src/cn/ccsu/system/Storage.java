package cn.ccsu.system;

public class Storage {

	public Storage() {

	}

	public boolean check() {
//		System.out.println("����ڴ�....");
		return true;
		
	}

}
