package cn.ccsu.system;

public class Disk {

	public Disk() {
		
	}

	public boolean read(){
//		System.out.println("��ȡӲ��...");
		return true;
		
	}

}
