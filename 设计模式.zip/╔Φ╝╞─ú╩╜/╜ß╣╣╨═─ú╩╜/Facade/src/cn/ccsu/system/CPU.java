package cn.ccsu.system;

public class CPU {

	public CPU() {

	}

	public boolean run() {

		return true;
	}

}
