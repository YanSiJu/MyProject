package cn.ccsu.system;

public class OS {

	public OS() {

	}

	public boolean load() {
//		System.out.println("����ϵͳ����...");
		return true;

	}
}
