package cn.csu.service;

public interface IBehavior {

	void bahave(String birdType);
}
