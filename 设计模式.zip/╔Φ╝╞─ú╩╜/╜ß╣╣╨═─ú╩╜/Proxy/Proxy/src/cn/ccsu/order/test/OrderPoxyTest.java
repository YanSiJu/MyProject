package cn.ccsu.order.test;

import org.junit.Test;


public class OrderPoxyTest {

	@Test
	public void test() {

//		public OrderProxy(String commodityName, int commodityNumber, String cusName) 
	}
}
