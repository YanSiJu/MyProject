package cn.csu.stock.observer;

public abstract class Observer {

	public Observer() {

	}

	public abstract void response(double range, double price);

}
