package cn.ccsu.simpleFactory;

public class Multi extends Operation {

	@Override
	public double getResult() {
		// TODO Auto-generated method stub
		
		return this.getNumber1() * this.getNumber2();
	}

}
