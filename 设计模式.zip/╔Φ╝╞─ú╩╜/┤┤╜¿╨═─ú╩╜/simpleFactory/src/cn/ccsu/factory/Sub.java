package cn.ccsu.simpleFactory;

public class Sub extends Operation {

	@Override
	public double getResult() {
		// TODO Auto-generated method stub

		return this.getNumber1() - this.getNumber2();

	}

}
