package cn.csu.product;

public class BenzORV extends AbstractBenz {

	@Override
	public void drive() {

		System.out.println("BenzORV  is driving");

	}

}
