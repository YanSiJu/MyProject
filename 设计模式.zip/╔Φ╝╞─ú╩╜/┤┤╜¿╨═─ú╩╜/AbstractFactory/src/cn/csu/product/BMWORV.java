package cn.csu.product;

public class BMWORV extends AbstractBMW {

	@Override
	public void drive() {
		System.out.println("BMWORV  is driving");

	}

}
