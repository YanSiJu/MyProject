package cn.csu.product;

public abstract class AbstractBenz {

	public abstract void drive();
	
}
