package cn.csu.product;

public abstract class AbstractBMW {

	public abstract void drive();
}
