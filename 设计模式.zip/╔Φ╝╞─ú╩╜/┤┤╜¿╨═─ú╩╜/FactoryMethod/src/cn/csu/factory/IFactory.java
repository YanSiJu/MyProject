package cn.csu.factory;

import cn.csu.product.Operation;

public interface IFactory {
	
	public Operation getproduct();

}
