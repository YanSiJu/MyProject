package cn.csu.product;

public class Multi extends Operation {

	@Override
	public double getResult() {
		
		return this.getNumber1() * this.getNumber2();
	}

}
