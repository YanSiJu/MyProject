package cn.ccsu.test;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
import org.junit.Test;

import cn.ccsu.arithmetic.Sort;

public class QuicklySortTest {

	@Test
	public void quicklySortTest() {
		Random random = new Random();
		Scanner in = new Scanner(System.in);

		System.out.println("����������������ָ���:");
		Integer[] a = new Integer[in.nextInt()];
		for (int i = 0; i < a.length; i++) {

			a[i] = random.nextInt() / 10000000;
		}

		Sort<Integer> sort = new Sort<>();
		System.out.println("����ǰ:" + Arrays.toString(a));
		 sort.quicklySort(a, 0, a.length - 1);
//		sort.median(a, 0, a.length - 1);
		System.out.println("�����:" + Arrays.toString(a));

		in.close();
	}

}
