package cn.ccsu.arithmetic;

/**
 * @author Bill
 *
 * @param <T>
 */
public class Sort<T extends Comparable<T>> {

	public T median(T[] a, int left, int right) {

		int center = (left + right) / 2;
		if (a[center].compareTo(a[left]) < 0)
			swap(a, left, center);
		if (a[right].compareTo(a[left]) < 0)
			swap(a, left, right);
		if (a[right].compareTo(a[center]) < 0)
			swap(a, center, right);

		// Place pivot at position right - 1
		swap(a, center, right);
		return a[right];

	}

	public void quicklySort(T[] a, int left, int right) {

		if (left + 2 <= right) {
			T pivot = median(a, left, right);
			// int center = (left + right) / 2;
			int i = left;
			// change
			int j = right;
			for (;;) {
				while (a[++i].compareTo(pivot) < 0) {

				}
				while (a[--j].compareTo(pivot) > 0) {

				}
				if (i < j)
					swap(a, i, j);
				else
					break;
			}

			// change
			swap(a, i, right);
			quicklySort(a, left, i - 1);

			quicklySort(a, i + 1, right);
		} else {
			insetrSort(a);
		}

	}

	private void swap(T[] a, int m, int n) {

		T tmp = a[m];
		a[m] = a[n];
		a[n] = tmp;
	}

	public void insetrSort(T[] a) {
		// TODO Auto-generated method stub

		T tmp;
		int j;
		for (int i = 1; i < a.length; i++) {
			tmp = a[i];
			for (j = i - 1; j >= 0; j--) {
				if (a[j].compareTo(tmp) > 0)
					a[j + 1] = a[j];
				else
					break;
			}
			a[j + 1] = tmp;
		}
	}
}
