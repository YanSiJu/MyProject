package cn.ccsu.test;

import java.awt.Color;
import javax.swing.JFrame;

import org.junit.Test;

public class Main {

	public Main() {

	}

	@Test
	public void test() {
		JFrame f = new JFrame();
		f.setSize(400, 300);
		f.setLocation(400, 300);
		f.setBackground(Color.blue);
		((JFrame) f).getContentPane().setBackground(Color.red);
		((JFrame) f).getContentPane().setVisible(false);// �����Ϊtrue��ô�ͱ���˺�ɫ��
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}
}
