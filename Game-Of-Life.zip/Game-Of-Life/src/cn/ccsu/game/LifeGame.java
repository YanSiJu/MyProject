package cn.ccsu.game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LifeGame extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final World world;

	public LifeGame(int rows, int columns, int speed) {
		world = new World(rows, columns,speed);
		new Thread(world).start();
		add(world);
	}

	/*public static void main(String[] args) {
		LifeGame frame = new LifeGame(40, 50);

	}*/

	public static void setFrame(LifeGame frame,int length,int wide) {

		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(length, wide);		//�����С:1007 859
//		frame.setBackground(Color.blue);
		frame.setTitle("Game of Life");
		frame.setVisible(true);
		frame.setResizable(false);
	}

	public static void setMenu(LifeGame frame) {

		JMenuBar menu = new JMenuBar();
		frame.setJMenuBar(menu);

		JMenu options = new JMenu("Options");
		menu.add(options);

		JMenuItem arrow = options.add("Arrow");
		arrow.addActionListener(frame.new ArrowActionListener());
		JMenuItem square = options.add("Square");
		square.addActionListener(frame.new SquareActionListener());

		JMenu help = new JMenu("Help");
		menu.add(help);
	}

	class ArrowActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			world.setArrow();
		}
	}

	class SquareActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			world.setSquare();
		}
	}
}
