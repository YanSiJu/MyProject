
public class rect_angle implements Printable{
	protected int m_x,m_y;
	private int m_width,m_height;
	
	public rect_angle() {
	  }
	  public rect_angle(int w,int h){
	    m_width = w;
	    m_height = h;
	  }
	  public rect_angle(int X, int Y, int w, int h){
	    this(w,h);
	    m_x = X;
	    m_y = Y;
	  }
	  public rect_angle(rect_angle r){
	    this(r.m_width,r.m_height);
	    m_x = r.m_x;
	    m_y = r.m_y;
	  }
	  
	// 请完成计算周长的方法
		public int calLength(){
			return 2*(m_width+m_height);
		}
	// 请完成计算面积的方法
		public int calArea(){
			return m_width*m_height;
		}

	public static void main(String[] args) {
		//rect_angle ra = new rect_angle(2,2,5,3);
		//ra.printWay('*');
				
		square sq = new square(1,1,5);
		sq.printWay('*');
	}
	@Override
	public void printWay() {
		System.out.println( "长方形的信息：左上角X坐标:"+m_x +
				"  左上角Y坐标:"+ m_y +
				"  高：" + this.m_height +
				"  宽：" + this.m_width +
				"  周长： " + this.calLength() +
				"  面积： " + this.calArea());
	}
	@Override
	public void printWay(char ch) {
		for(int i=0;i<this.m_height;i++){
			for(int j=0;j<this.m_width;j++){
				System.out.print(ch);
			}
			System.out.println( );
		}
	}

}
