package cn.ccsu.bean;

public class Latte extends Coffee {

	public static final double prize = 10;

	public Latte() {
		this.setPrize(prize);
	}
		
}
