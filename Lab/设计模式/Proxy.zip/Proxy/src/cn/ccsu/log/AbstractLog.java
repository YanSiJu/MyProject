package cn.ccsu.log;

public abstract class AbstractLog {

	public abstract int method(int m, int n);
}
