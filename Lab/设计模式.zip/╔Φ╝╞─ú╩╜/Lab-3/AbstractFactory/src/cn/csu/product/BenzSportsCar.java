package cn.csu.product;

public class BenzSportsCar extends AbstractBenz {

	@Override
	public void drive() {

		System.out.println("BenzSportsCar  is  driving");

	}

}
