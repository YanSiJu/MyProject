package cn.csu.product;

public class BMWSportsCar extends AbstractBMW {

	@Override
	public void drive() {
		System.out.println("BMWSportsCar  is  driving");

	}

}
