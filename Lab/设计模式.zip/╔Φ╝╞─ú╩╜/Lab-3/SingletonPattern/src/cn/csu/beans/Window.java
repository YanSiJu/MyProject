package cn.csu.beans;

public class Window {

	private static Window window = new Window();

	private Window() {

	}

	public static Window getWindow() {

		return window;
	}

}
