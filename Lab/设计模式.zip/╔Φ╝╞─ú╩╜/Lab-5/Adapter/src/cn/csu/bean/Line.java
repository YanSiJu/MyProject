package cn.csu.bean;

public class Line extends AbstractGraph {

	@Override
	public void draw() {
		System.out.println("Draw Line");
	}
}
