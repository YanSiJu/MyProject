/**
 * 
 */
/**
 * @author Bill
 *
 */
package cn.csu.bean;